<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header">
                <h3 class="box-title">
                Please navigate to the appropriate controller / action to open the associated function with your generated code.
                </h3>
            </div>
        </div>
    </div>
</div>